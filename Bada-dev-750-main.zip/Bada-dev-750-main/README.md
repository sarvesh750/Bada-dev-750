# Bada-dev-750
aviator predictor code
